import boto3
region = 'Region you are in'
instance = ['Instance ID here']
ec2 = boto3.client('ec2', region_name=region)

def lambda_handler(event, context):
    ec2.start_instances(InstanceIds=instance)
    print('Start Instance: ' + str(instance))
